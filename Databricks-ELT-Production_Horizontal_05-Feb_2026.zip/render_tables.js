// Add this script BEFORE the closing </script> tag around line 12304

// Populate Available Tables dynamically from tableMetadata
function renderAvailableTables() {
    const tableList = document.getElementById('tableList');
    if (!tableList) return;

    tableList.innerHTML = ''; // Clear existing tables

    // Get all tables from table Metadata and sort them
    Object.keys(tableMetadata).sort().forEach(tableName => {
        const displayName = tableName.split('.')[1]; // Remove 'dw.' prefix
        const html = `
      <div class="table-item" onclick="addTableToCanvas('${tableName}')" data-table="${tableName}" title="${tableName}">
        <div><strong>${displayName}</strong></div>
        <small class="text-muted">${tableName}</small>
      </div>
    `;
        tableList.insertAdjacentHTML('beforeend', html);
    });
}

// Call on page load
$(document).ready(function () {
    renderAvailableTables();
});
